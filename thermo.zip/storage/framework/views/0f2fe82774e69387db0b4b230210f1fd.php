<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e($title); ?> <?php $__env->endSlot(); ?>

    <section>
        <div
            class="flex flex-row lg:grid max-w-screen-xl px-1 py-2 md:px-4 md:py-8 md:gap-3 mx-auto gap-1 lg:grid-cols-12 items-center">
            
            <div class="text-left w-32 md:w-max lg:text-left lg:col-span-6">
                <h1
                    class="max-w-2xl mb-2 text-4xl font-extrabold tracking-tight leading-none md:text-5xl xl:text-6xl text-quiz-light-text dark:text-quiz-dark-text">
                    ThermoWoosh
                </h1>
                <h2
                    class="max-w-2xl mb-2 font-semibold text-quiz-light-button-hover dark:text-quiz-dark-button lg:mb-4 md:text-lg lg:text-xl">
                    Serunya Belajar Termodinamika!
                </h2>
                <p class="max-w-2xl mb-4 font-light text-quiz-light-text dark:text-quiz-dark-text md:text-lg lg:text-xl">
                    Website interaktif fisika <br>
                    Discovery Learning
                </p>
                <a href="/materi"
                    class="inline-flex items-center justify-center px-5 py-3 mb-4 text-base font-medium text-center bg-quiz-light-button-hover border-2 dark:bg-quiz-dark-button text-quiz-light-text border-quiz-light-text rounded-lg hover:bg-quiz-light-button focus:ring-4 focus:ring-quiz-light-text dark:text-quiz-dark-text dark:border-quiz-dark-text dark:hover:bg-gray-700 dark:focus:ring-gray-800">
                    Mulai Belajar
                    <svg class="w-5 h-5 ml-2 -mr-1" fill="currentColor" viewBox="0 0 20 20"
                        xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd"
                            d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z"
                            clip-rule="evenodd"></path>
                    </svg>
                </a>
            </div>
            
            <div class="flex justify-center lg:justify-end lg:col-span-4">
                
                <img src="data:image/png;base64,<?php echo e(htmlspecialchars(pg_unescape_bytea(stream_get_contents(App\Models\Images::all()->find(2)->content)))); ?>"
                    alt="landing-image" class="w-72 md:w-80 lg:w-96 aspect-square">
            </div>

        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\DevKit\laragon\www\thermo-woosh\resources\views\beranda.blade.php ENDPATH**/ ?>