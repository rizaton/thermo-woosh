<x-layout>
    <x-slot:title>{{ $title }}</x-slot:title>
    <section>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dicta, illum.</p>
    </section>
</x-layout>
